﻿print('"Hello World"')
