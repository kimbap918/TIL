﻿n = ord(input()) # 입력값을 유니코드로 저장
print(n)
