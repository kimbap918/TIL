﻿a, b = map(int, input().split())
print(not(a or b)) 


