﻿c = int(input())
print(chr(c)) # 입력받은 값을 유니코드로 출력
