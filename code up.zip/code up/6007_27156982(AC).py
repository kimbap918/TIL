﻿print("\"C:\\Download\\\'hello\'.py\"")
