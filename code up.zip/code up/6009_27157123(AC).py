﻿a = input()
print(a)
