﻿f1, f2 = map(float, input().split())
print(f1 * f2)
