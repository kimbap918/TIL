﻿a = input() 
n = int(a)            
print('%x'%n)
