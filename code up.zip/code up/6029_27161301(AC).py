﻿a = input() 
n = int(a, 16) # a를 16진수로 저장
print('%o' %n) 
