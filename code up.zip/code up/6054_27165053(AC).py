﻿a, b = map(int, input().split())
print(bool(a) and bool(b))
