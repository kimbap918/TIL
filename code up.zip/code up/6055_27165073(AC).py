﻿a, b = map(int, input().split())
print(bool(a) or bool(b))
