﻿a = ""
b = "q"
while a != b:
    a = input()
    print(a)
