﻿print("Hello")
