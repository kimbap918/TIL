﻿a = int(input())
b = input()
print(a*b)
