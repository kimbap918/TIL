﻿f = float(input())
print(f)
print(f)
print(f)
