﻿a = int(input())
b = 0
for i in range(a+1):
    print(b)
    b += 1
