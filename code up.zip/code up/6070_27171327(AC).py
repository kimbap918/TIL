﻿a = int(input())
if a//3 == 0 or a//3 == 4:
    print("winter")
elif a//3 == 1:
    print("spring")
elif a//3 == 2:
    print("summer")
elif a//3 == 3:
    print("fall")
