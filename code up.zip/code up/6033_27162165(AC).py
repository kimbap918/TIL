﻿a = ord(input()) # 설명이 이상함, 8진법으로 입력받아서 출력
print(chr(a+1))
