﻿a, b = input().split()
print(a*int(b))
