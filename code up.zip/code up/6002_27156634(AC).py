﻿print("Hello World")

