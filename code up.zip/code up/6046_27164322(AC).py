﻿a = int(input())
print(a<<1)
