﻿y, m, d = input().split('.')
print(d, m, y, sep='-')
