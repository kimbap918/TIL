﻿a = int(input())
b = 0
while b <= a:
    print(b)
    b += 1
