﻿s = input().split('-')
print(s[0]+s[1])
