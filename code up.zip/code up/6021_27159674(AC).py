﻿s = input()
for i in range(len(s)):
    print(s[i])
