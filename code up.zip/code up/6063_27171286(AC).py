﻿a, b = map(int, input().split())
c = (a if (a>=b) else b)
print(int(c))
