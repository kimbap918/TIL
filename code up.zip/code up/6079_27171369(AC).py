﻿a = int(input())
b = 0
c = 0
while b < a:
    c += 1
    b += c
print(c)
