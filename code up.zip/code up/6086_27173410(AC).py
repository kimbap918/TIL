﻿a = int(input())
b = 0
c = 0
while True:
    b += 1
    c += b
    if c >= a:
        print(c)
        break
   
