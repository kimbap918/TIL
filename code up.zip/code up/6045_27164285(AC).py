﻿a, b, c = map(int, input().split())
print(a+b+c, format((a+b+c)/3, ".2f"))
