﻿a, b = map(int, input().split())
print(b >= a)
