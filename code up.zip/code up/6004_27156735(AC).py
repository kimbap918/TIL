﻿print("'Hello'")
