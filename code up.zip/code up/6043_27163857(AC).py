﻿f1, f2 = map(float, input().split())
print(format(f1/f2, ".3f"))
