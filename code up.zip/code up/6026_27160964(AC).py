﻿f1 = float(input())
f2 = float(input())
print(f1+f2)
