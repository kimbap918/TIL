﻿f = float(input())
print(f)
