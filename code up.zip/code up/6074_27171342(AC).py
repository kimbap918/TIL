﻿c = ord(input())
b = ord("a")
while b <= c:
    print(chr(b), end=' ')
    b += 1

