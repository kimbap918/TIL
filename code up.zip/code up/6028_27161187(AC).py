﻿a = input() 
n = int(a)            
print('%X'%n) # 대문자 형태로
