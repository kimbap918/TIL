# 1번 문제
# n = int(input())
# if n % 3 == 0 and n % 2 == 0:
#     print("참")
# else:
#     print("거짓")


# # 2번 문제
# word = 'happy!'
# cnt = 0
# for i in word:
#     cnt += 1
# print(cnt)

# word = "happy!"
# cnt1 = 0
# while cnt1 < len(word):
#     cnt1 += 1
# print(cnt1)

# # 3번 문제
# # while
# n = int(input())
# a = 0
# b = 0
# while n > a:
#     a += 1
#     b += a
# print(b)

# # for
# n = int(input())
# a = 0
# b = 0
# for i in range(n):
#   a += 1
#   b += a
# print(b)

# 4번문제
# # while
# n = int(input())
# a = 1
# b = 1
# while n > a:
#   a += 1
#   b *= a
# print(b)

# # for
# n = int(input())
# a = 1
# b = 1
# for i in range(n-1):
#   a += 1
#   b *= a
# print(b)

# # 5번 문제
# numbers = [3, 10, 20]
# a= 0
# for i in range(3):
#   a += numbers[i]
# print(a/3)

# # 6번 문제
# numbers = [0, 20, 100]
# # numbers = [0, 20, 100, 50, -60, 50, 100]
# # numbers = [0, 1, 0]
# # numbers = [-10, -100, -30]
# max = -9999
# for i in range(len(numbers)):
#   if max < numbers[i]:
#     max = numbers[i]
# print(max)

# # 7번 문제
# numbers = [0, 20, 100]
# # numbers = [0, 20, 100, 50, -60, 50, 100]
# # numbers = [0, 1, 0]
# # numbers = [-10, -100, -30]
# min = 9999
# for i in range(len(numbers)):
#   if min > numbers[i]:
#     min = numbers[i]
# print(min)