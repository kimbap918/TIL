﻿print("print(\"Hello\\nWorld\")")
