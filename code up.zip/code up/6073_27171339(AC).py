﻿n = int(input())
while n != 0:
    print(n-1)
    n -= 1
