﻿print("Hello")
print("World")
