﻿s = input().split(':')
print(s[1])
