﻿a = int(input())
if a <= 100 and a >= 90:
    print("A")
elif a <= 89 and a >= 70:
    print("B")
elif a <= 69 and a >= 40:
    print("C")
elif a <= 39 and a >= 0:
    print("D")
