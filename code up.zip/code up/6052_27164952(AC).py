﻿a = int(input()) 
print(bool(a)) 
